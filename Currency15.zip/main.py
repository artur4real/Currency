import sys
from PyQt5.QtWidgets import QDialog,QApplication,QMainWindow,QLabel,QRadioButton,QCheckBox,QMessageBox,QSpinBox,QPushButton,QComboBox,QVBoxLayout,QMessageBox
from PyQt5 import uic
from database import Database

class MainWindow(QMainWindow):
    def __init__(self, user_id):
        super(MainWindow, self).__init__()
        self.user_id = user_id
        uic.loadUi("untitled.ui", self)
        self.db = Database(host='localhost', user='root', password='', database='Convertor')
        self.populate_currency_comboboxes()  # вызываем метод для заполнения comboBox

        self.pushButton_32.clicked.connect(self.exchange_currency)
        self.pushButton_orders.clicked.connect(self.show_transaction_window)

    def show_transaction_window(self):
        self.transaction_window = TransactionWindow(self.user_id)
        self.transaction_window.show()

    def exchange_currency(self):
        # Получаем выбранные валюты из comboBox
        source_currency = self.comboBox.currentText()
        target_currency = self.comboBox_2.currentText()

        # Получаем сумму для обмена из lineEdit
        amount = int(self.lineEdit.text())

        # Получаем курс обмена из базы данных
        query = "SELECT rate FROM Exchange_Rates WHERE from_currency = " \
                "(SELECT currency_id FROM Currencies WHERE name = %s) " \
                "AND to_currency = (SELECT currency_id FROM Currencies WHERE name = %s)"
        self.db.cursor.execute(query, (source_currency, target_currency))
        rate = self.db.cursor.fetchone()[0]

        # Вычисляем сумму после обмена
        target_amount = amount * rate

        # Проверяем, достаточно ли средств на балансе пользователя
        query = "SELECT balance FROM Users WHERE user_id = %s"
        self.db.cursor.execute(query, (self.user_id,))
        current_balance = self.db.cursor.fetchone()[0]

        if current_balance >= target_amount:
            # Обновляем баланс пользователя
            query = "UPDATE Users SET balance = balance - %s WHERE user_id = %s"
            self.db.cursor.execute(query, (target_amount, self.user_id))
            self.db.connection.commit()

            # Записываем операцию обмена в Transaction_History
            query = "INSERT INTO Transaction_History " \
                    "(user_id, source_currency, target_currency, source_amount, target_amount, date_time) VALUES " \
                    "(%s, (SELECT currency_id FROM Currencies WHERE name = %s), " \
                    "(SELECT currency_id FROM Currencies WHERE name = %s), %s, %s, NOW())"
            self.db.cursor.execute(query, (self.user_id, source_currency, target_currency, amount, target_amount))
            self.db.connection.commit()

            # Записываем операцию обмена в Exchange_Operations
            query = "INSERT INTO Exchange_Operations " \
                    "(user_id, source_currency, target_currency, source_amount, target_amount, date_time) " \
                    "VALUES (%s, (SELECT currency_id FROM Currencies WHERE name = %s)," \
                    " (SELECT currency_id FROM Currencies WHERE name = %s), %s, %s, NOW())"
            self.db.cursor.execute(query, (self.user_id, source_currency, target_currency, amount, target_amount))
            self.db.connection.commit()

            # Проверяем, существует ли уже такой обмен в Exchange_Rates
            query = "SELECT * FROM Exchange_Rates WHERE from_currency = " \
                    "(SELECT currency_id FROM Currencies WHERE name = %s)" \
                    "AND to_currency = (SELECT currency_id FROM Currencies WHERE name = %s)"
            self.db.cursor.execute(query, (source_currency, target_currency))
            existing_exchange = self.db.cursor.fetchone()

            if existing_exchange:
                # Если обмен уже существует, обновляем его курс
                query = "UPDATE Exchange_Rates SET rate = %s WHERE from_currency = " \
                        "(SELECT currency_id FROM Currencies WHERE name = %s) " \
                        "AND to_currency = (SELECT currency_id FROM Currencies WHERE name = %s)"
                self.db.cursor.execute(query, (rate, source_currency, target_currency))
                self.db.connection.commit()
            else:
                # Если обмен не существует, добавляем новый
                query = "INSERT INTO Exchange_Rates (from_currency, to_currency, rate) " \
                        "VALUES ((SELECT currency_id FROM Currencies WHERE name = %s)," \
                        " (SELECT currency_id FROM Currencies WHERE name = %s), %s)"
                self.db.cursor.execute(query, (source_currency, target_currency, rate))
                self.db.connection.commit()

            # Очищаем lineEdit после записи операции
            self.lineEdit.clear()

            # Показываем сообщение об успешной покупке
            QMessageBox.information(self, "Успешная покупка", "Обмен прошел успешно!")
        else:
            # Выводим сообщение об ошибке, если баланс недостаточен
            QMessageBox.warning(self, "Ошибка", "Недостаточно средств на балансе!")

    def populate_currency_comboboxes(self):
        # Очищаем comboBox перед добавлением новых элементов
        self.comboBox.clear()
        self.comboBox_2.clear()

        # Получаем валютные пары из базы данных
        query = "SELECT name FROM Currencies"
        self.db.cursor.execute(query)
        currency_pairs = self.db.cursor.fetchall()

        # Добавляем валютные пары в comboBox
        for pair in currency_pairs:
            self.comboBox.addItem(pair[0])
            self.comboBox_2.addItem(pair[0])

        # Устанавливаем значения по умолчанию для comboBox
        self.comboBox.setCurrentIndex(0)
        self.comboBox_2.setCurrentIndex(1)

class TransactionWindow(QMainWindow):
    def __init__(self, user_id):
        super(TransactionWindow, self).__init__()
        uic.loadUi("orders.ui", self)  # Замените "orders.ui" на путь к вашему файлу ui
        self.user_id = user_id
        self.db = Database(host='localhost', user='root', password='', database='Convertor')
        self.currency_dict = self.create_currency_dict()  # Создаем словарь с буквенными значениями валют
        self.populate_transactions()

    def create_currency_dict(self):
        # Создаем словарь, который соответствует числовым значениям валют их буквенным эквивалентам
        currency_dict = {}
        query = "SELECT currency_id, name FROM Currencies"
        self.db.cursor.execute(query)
        currencies = self.db.cursor.fetchall()
        for currency in currencies:
            currency_dict[currency[0]] = currency[1]
        return currency_dict

    def populate_transactions(self):
        query = "SELECT * FROM Transaction_History WHERE user_id = %s"
        self.db.cursor.execute(query, (self.user_id,))
        transactions = self.db.cursor.fetchall()

        for transaction in transactions:
            source_currency = self.currency_dict.get(transaction[2])  # Получаем буквенное значение исходной валюты
            target_currency = self.currency_dict.get(transaction[3])  # Получаем буквенное значение целевой валюты
            transaction_text = f"Source Currency: {source_currency}, Target Currency: {target_currency}, " \
                                f"Source Amount: {transaction[4]}, " \
                                f"Date Time: {transaction[6]}"
            label = QLabel(transaction_text)
            self.verticalLayout.addWidget(label)


class Aut(QMainWindow):
    def __init__(self):
        super(Aut, self).__init__()
        uic.loadUi("Login.ui", self)
        self.db = Database(host='localhost', user='root', password='', database='Convertor')
        self.pushButton.clicked.connect(self.aut)

    # Авторизация
    def aut(self):
        login = self.lineEdit.text()
        password = self.lineEdit_2.text()

        try:
            query = "SELECT id ,login, password FROM Avto WHERE login = %s AND password = %s"
            self.db.cursor.execute(query, (login, password))
            result = self.db.cursor.fetchone()

            if result:
                self.user_id = result[0]
                self.hide()  # Скрываем окно авторизации
                self.show_main_window()  # Показываем главное окно
            else:
                QMessageBox.critical(self, "Ошибка в авторизации",
                                     "Ошибка в авторизации\nНеверно набран логин или пароль")
        except Exception as e:
            QMessageBox.critical(self, "Ошибка", f"Произошла ошибка: {str(e)}")

    def show_main_window(self):
        self.main_window = MainWindow(self.user_id)
        self.main_window.show()


if __name__ == '__main__':
    app = QApplication(sys.argv)
    window = Aut()
    window.show()
    app.exit(app.exec_())


