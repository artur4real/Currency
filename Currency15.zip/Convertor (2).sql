-- phpMyAdmin SQL Dump
-- version 5.2.0
-- https://www.phpmyadmin.net/
--
-- Хост: 127.0.0.1:3306
-- Время создания: Мар 22 2024 г., 03:35
-- Версия сервера: 5.6.51
-- Версия PHP: 7.2.34

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- База данных: `Convertor`
--

-- --------------------------------------------------------

--
-- Структура таблицы `Avto`
--

CREATE TABLE `Avto` (
  `id` int(11) NOT NULL,
  `login` varchar(50) COLLATE utf8mb4_unicode_ci NOT NULL,
  `password` varchar(50) COLLATE utf8mb4_unicode_ci NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Дамп данных таблицы `Avto`
--

INSERT INTO `Avto` (`id`, `login`, `password`) VALUES
(1, 'shamil', 'shamil');

-- --------------------------------------------------------

--
-- Структура таблицы `Currencies`
--

CREATE TABLE `Currencies` (
  `currency_id` int(11) NOT NULL,
  `name` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `code` char(3) COLLATE utf8mb4_unicode_ci DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Дамп данных таблицы `Currencies`
--

INSERT INTO `Currencies` (`currency_id`, `name`, `code`) VALUES
(1, 'US Dollar', 'USD'),
(2, 'Euro', 'EUR'),
(3, 'British Pound', 'GBP');

-- --------------------------------------------------------

--
-- Структура таблицы `Exchange_Operations`
--

CREATE TABLE `Exchange_Operations` (
  `operation_id` int(11) NOT NULL,
  `user_id` int(11) DEFAULT NULL,
  `source_currency` int(11) DEFAULT NULL,
  `target_currency` int(11) DEFAULT NULL,
  `source_amount` int(11) DEFAULT NULL,
  `target_amount` int(11) DEFAULT NULL,
  `date_time` datetime DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Дамп данных таблицы `Exchange_Operations`
--

INSERT INTO `Exchange_Operations` (`operation_id`, `user_id`, `source_currency`, `target_currency`, `source_amount`, `target_amount`, `date_time`) VALUES
(1, 1, 1, 2, 500, 425, '2024-03-22 09:00:00'),
(2, 2, 2, 3, 300, 255, '2024-03-22 09:30:00'),
(3, 3, 3, 1, 100, 139, '2024-03-22 10:00:00');

-- --------------------------------------------------------

--
-- Структура таблицы `Exchange_Rates`
--

CREATE TABLE `Exchange_Rates` (
  `exchange_id` int(11) NOT NULL,
  `from_currency` int(11) DEFAULT NULL,
  `to_currency` int(11) DEFAULT NULL,
  `rate` int(11) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Дамп данных таблицы `Exchange_Rates`
--

INSERT INTO `Exchange_Rates` (`exchange_id`, `from_currency`, `to_currency`, `rate`) VALUES
(1, 1, 2, 1),
(2, 1, 3, 1),
(3, 2, 1, 1),
(4, 2, 3, 1),
(5, 3, 1, 1),
(6, 3, 2, 1);

-- --------------------------------------------------------

--
-- Структура таблицы `Transaction_History`
--

CREATE TABLE `Transaction_History` (
  `transaction_id` int(11) NOT NULL,
  `user_id` int(11) DEFAULT NULL,
  `source_currency` int(11) DEFAULT NULL,
  `target_currency` int(11) DEFAULT NULL,
  `source_amount` int(11) DEFAULT NULL,
  `target_amount` int(11) DEFAULT NULL,
  `date_time` datetime DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Структура таблицы `Users`
--

CREATE TABLE `Users` (
  `user_id` int(11) NOT NULL,
  `first_name` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `last_name` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `email` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `phone` varchar(20) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `address` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `balance` int(11) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Дамп данных таблицы `Users`
--

INSERT INTO `Users` (`user_id`, `first_name`, `last_name`, `email`, `phone`, `address`, `balance`) VALUES
(1, 'John', 'Doe', 'john.doe@example.com', '+1234567890', '123 Main St, City', 1000),
(2, 'Alice', 'Smith', 'alice.smith@example.com', '+1987654321', '456 Elm St, Town', 500),
(3, 'Bob', 'Johnson', 'bob.johnson@example.com', '+1122334455', '789 Oak St, Village', 2000);

--
-- Индексы сохранённых таблиц
--

--
-- Индексы таблицы `Avto`
--
ALTER TABLE `Avto`
  ADD PRIMARY KEY (`id`);

--
-- Индексы таблицы `Currencies`
--
ALTER TABLE `Currencies`
  ADD PRIMARY KEY (`currency_id`);

--
-- Индексы таблицы `Exchange_Operations`
--
ALTER TABLE `Exchange_Operations`
  ADD PRIMARY KEY (`operation_id`),
  ADD KEY `user_id` (`user_id`),
  ADD KEY `source_currency` (`source_currency`),
  ADD KEY `target_currency` (`target_currency`);

--
-- Индексы таблицы `Exchange_Rates`
--
ALTER TABLE `Exchange_Rates`
  ADD PRIMARY KEY (`exchange_id`),
  ADD KEY `from_currency` (`from_currency`),
  ADD KEY `to_currency` (`to_currency`);

--
-- Индексы таблицы `Transaction_History`
--
ALTER TABLE `Transaction_History`
  ADD PRIMARY KEY (`transaction_id`),
  ADD KEY `user_id` (`user_id`),
  ADD KEY `source_currency` (`source_currency`),
  ADD KEY `target_currency` (`target_currency`);

--
-- Индексы таблицы `Users`
--
ALTER TABLE `Users`
  ADD PRIMARY KEY (`user_id`);

--
-- AUTO_INCREMENT для сохранённых таблиц
--

--
-- AUTO_INCREMENT для таблицы `Avto`
--
ALTER TABLE `Avto`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- AUTO_INCREMENT для таблицы `Currencies`
--
ALTER TABLE `Currencies`
  MODIFY `currency_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;

--
-- AUTO_INCREMENT для таблицы `Exchange_Operations`
--
ALTER TABLE `Exchange_Operations`
  MODIFY `operation_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;

--
-- AUTO_INCREMENT для таблицы `Exchange_Rates`
--
ALTER TABLE `Exchange_Rates`
  MODIFY `exchange_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=7;

--
-- AUTO_INCREMENT для таблицы `Transaction_History`
--
ALTER TABLE `Transaction_History`
  MODIFY `transaction_id` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT для таблицы `Users`
--
ALTER TABLE `Users`
  MODIFY `user_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;

--
-- Ограничения внешнего ключа сохраненных таблиц
--

--
-- Ограничения внешнего ключа таблицы `Exchange_Operations`
--
ALTER TABLE `Exchange_Operations`
  ADD CONSTRAINT `exchange_operations_ibfk_1` FOREIGN KEY (`user_id`) REFERENCES `Users` (`user_id`),
  ADD CONSTRAINT `exchange_operations_ibfk_2` FOREIGN KEY (`source_currency`) REFERENCES `Currencies` (`currency_id`),
  ADD CONSTRAINT `exchange_operations_ibfk_3` FOREIGN KEY (`target_currency`) REFERENCES `Currencies` (`currency_id`);

--
-- Ограничения внешнего ключа таблицы `Exchange_Rates`
--
ALTER TABLE `Exchange_Rates`
  ADD CONSTRAINT `exchange_rates_ibfk_1` FOREIGN KEY (`from_currency`) REFERENCES `Currencies` (`currency_id`),
  ADD CONSTRAINT `exchange_rates_ibfk_2` FOREIGN KEY (`to_currency`) REFERENCES `Currencies` (`currency_id`);

--
-- Ограничения внешнего ключа таблицы `Transaction_History`
--
ALTER TABLE `Transaction_History`
  ADD CONSTRAINT `transaction_history_ibfk_1` FOREIGN KEY (`user_id`) REFERENCES `Users` (`user_id`),
  ADD CONSTRAINT `transaction_history_ibfk_2` FOREIGN KEY (`source_currency`) REFERENCES `Currencies` (`currency_id`),
  ADD CONSTRAINT `transaction_history_ibfk_3` FOREIGN KEY (`target_currency`) REFERENCES `Currencies` (`currency_id`);
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
