
def get_rate_query(from_currency, to_currency):
    return "SELECT rate FROM Exchange_Rates WHERE from_currency = (SELECT currency_id FROM Currencies WHERE name = %s) AND to_currency = (SELECT currency_id FROM Currencies WHERE name = %s)"

def update_user_balance_query(user_id, amount):
    return "UPDATE Users SET balance = balance - %s WHERE user_id = %s"

def insert_transaction_history_query(user_id, source_currency, target_currency, source_amount, target_amount):
    return "INSERT INTO Transaction_History (user_id, source_currency, target_currency, source_amount, target_amount, date_time) VALUES (%s, (SELECT currency_id FROM Currencies WHERE name = %s), (SELECT currency_id FROM Currencies WHERE name = %s), %s, %s, NOW())"

