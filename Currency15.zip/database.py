import pymysql

class Database:
    def __init__(self, host, user, password, database):
        try:
            self.connection = pymysql.connect(host=host, user=user, password=password, database=database)
            self.cursor = self.connection.cursor()
            print("ООО успешное подключение")
        except pymysql.Error as e:
            print("Увы не удача:", e)
